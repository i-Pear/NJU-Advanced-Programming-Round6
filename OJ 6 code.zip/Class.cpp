#include "Class.h"

void Class::add_inherit_class(const Class* c){

}

void Class::add_virtual_inherit_class(const Class* c){

}

void Class::add_member_object(const Class* c){

}

int Class::get_class_size() const{
    return 0;
}

void Class::add_member_function(const std::string&func_name, int (*func_ptr)()){

}

void Class::add_virtual_member_function(const std::string&func_name, int (*func_ptr)()){

}

int Class::call_member_function(const std::string&func_name){
    return 0;
}
